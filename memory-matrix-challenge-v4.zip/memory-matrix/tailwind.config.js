/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        display: ['"Orbitron"', 'monospace'],
        body: ['"DM Sans"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        neon: {
          cyan:    '#00f5ff',
          purple:  '#bf00ff',
          green:   '#00ff88',
          red:     '#ff3366',
          yellow:  '#ffee00',
          orange:  '#ff7700',
        },
      },
      animation: {
        'pulse-fast':   'pulse 0.6s ease-in-out infinite',
        'glow':         'glow 1.5s ease-in-out infinite',
        'shake':        'shake 0.4s ease-in-out',
        'pop':          'pop 0.3s cubic-bezier(0.34,1.56,0.64,1)',
        'fade-in':      'fadeIn 0.5s ease forwards',
        'slide-up':     'slideUp 0.5s cubic-bezier(0.22,1,0.36,1) forwards',
        'countdown':    'countdown 1s linear forwards',
        'scan':         'scan 2s linear infinite',
      },
      keyframes: {
        glow: {
          '0%,100%': { boxShadow: '0 0 5px #00f5ff, 0 0 20px #00f5ff' },
          '50%':     { boxShadow: '0 0 20px #00f5ff, 0 0 60px #00f5ff, 0 0 100px #00f5ff' },
        },
        shake: {
          '0%,100%': { transform: 'translateX(0)' },
          '20%':     { transform: 'translateX(-8px)' },
          '40%':     { transform: 'translateX(8px)' },
          '60%':     { transform: 'translateX(-5px)' },
          '80%':     { transform: 'translateX(5px)' },
        },
        pop: {
          '0%':   { transform: 'scale(0.8)', opacity: 0 },
          '100%': { transform: 'scale(1)',   opacity: 1 },
        },
        fadeIn: {
          from: { opacity: 0 },
          to:   { opacity: 1 },
        },
        slideUp: {
          from: { transform: 'translateY(30px)', opacity: 0 },
          to:   { transform: 'translateY(0)',    opacity: 1 },
        },
        scan: {
          '0%':   { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100%)' },
        },
      },
      backdropBlur: {
        xs: '2px',
      },
    },
  },
  plugins: [],
}
