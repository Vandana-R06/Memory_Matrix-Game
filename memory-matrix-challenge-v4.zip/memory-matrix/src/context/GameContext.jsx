/**
 * context/GameContext.jsx
 * ─────────────────────────────────────────────
 * Central state store for Memory Matrix Challenge.
 * Manages game phase, score, streaks, heatmap data,
 * level progression and persistence via localStorage.
 */
import React, {
  createContext, useContext, useReducer, useEffect, useCallback,
} from 'react'
import {
  getGridSize, getPatternLength, generatePattern,
  calculateScore, loadFromStorage, saveToStorage,
} from '../utils/gameUtils'

/* ─── Constants ──────────────────────────────────────────── */
export const PHASE = {
  IDLE:        'idle',       // before game starts
  MEMORIZE:    'memorize',   // pattern is shown
  RECALL:      'recall',     // user guessing
  VALIDATING:  'validating', // brief result flash
  LEVEL_UP:    'level_up',   // transition animation
  GAME_OVER:   'game_over',  // final screen
}

const ANSWER_TIMEOUT = 15 // seconds for answering (0 = off)

/* ─── Initial state ──────────────────────────────────────── */
const initialState = {
  phase:          PHASE.IDLE,
  level:          1,
  score:          0,
  streak:         0,
  maxStreak:      0,
  gridSize:       3,
  pattern:        [],       // array of cell indices that are "correct"
  userSelection:  [],       // cells the user has clicked
  heatmap:        {},       // { cellIndex: mistakeCount }
  memorizeTimer:  3,        // countdown while showing pattern (seconds)
  answerTimer:    ANSWER_TIMEOUT,
  startTime:      null,     // when recall phase began
  highScore:      loadFromStorage('mm_highScore', 0),
  bestStreak:     loadFromStorage('mm_bestStreak', 0),
  history:        [],       // past rounds for stats
}

/* ─── Reducer ─────────────────────────────────────────────── */
function gameReducer(state, action) {
  switch (action.type) {

    case 'START_GAME': {
      const gridSize = getGridSize(1)
      const pattern  = generatePattern(gridSize, getPatternLength(1))
      return {
        ...initialState,
        highScore:  state.highScore,
        bestStreak: state.bestStreak,
        phase:      PHASE.MEMORIZE,
        level:      1,
        gridSize,
        pattern,
        memorizeTimer: 3,
        answerTimer:   ANSWER_TIMEOUT,
        heatmap:    {},
      }
    }

    case 'TICK_MEMORIZE': {
      if (state.memorizeTimer <= 1) {
        // Switch to recall
        return { ...state, phase: PHASE.RECALL, memorizeTimer: 0, startTime: Date.now() }
      }
      return { ...state, memorizeTimer: state.memorizeTimer - 1 }
    }

    case 'TICK_ANSWER': {
      if (state.phase !== PHASE.RECALL) return state
      if (state.answerTimer <= 1) {
        // Time's up → game over
        return { ...state, phase: PHASE.GAME_OVER }
      }
      return { ...state, answerTimer: state.answerTimer - 1 }
    }

    case 'SELECT_CELL': {
      if (state.phase !== PHASE.RECALL) return state
      const idx = action.payload
      if (state.userSelection.includes(idx)) return state // already selected
      const newSelection = [...state.userSelection, idx]

      // Check if wrong immediately
      if (!state.pattern.includes(idx)) {
        const newHeatmap = { ...state.heatmap, [idx]: (state.heatmap[idx] || 0) + 1 }
        return {
          ...state,
          userSelection: newSelection,
          heatmap:       newHeatmap,
          phase:         PHASE.GAME_OVER,
        }
      }

      // All correct cells chosen?
      if (newSelection.length === state.pattern.length) {
        const elapsed   = (Date.now() - state.startTime) / 1000
        const points    = calculateScore(state.level, elapsed)
        const newScore  = state.score + points
        const newStreak = state.streak + 1
        const newMax    = Math.max(state.maxStreak, newStreak)
        const newHigh   = Math.max(state.highScore, newScore)
        const newBest   = Math.max(state.bestStreak, newMax)
        return {
          ...state,
          userSelection: newSelection,
          score:         newScore,
          streak:        newStreak,
          maxStreak:     newMax,
          highScore:     newHigh,
          bestStreak:    newBest,
          phase:         PHASE.VALIDATING,
          history:       [...state.history, { level: state.level, points, elapsed }],
        }
      }

      return { ...state, userSelection: newSelection }
    }

    case 'NEXT_LEVEL': {
      const nextLevel = state.level + 1
      const gridSize  = getGridSize(nextLevel)
      const pattern   = generatePattern(gridSize, getPatternLength(nextLevel))
      return {
        ...state,
        phase:         PHASE.MEMORIZE,
        level:         nextLevel,
        gridSize,
        pattern,
        userSelection: [],
        memorizeTimer: Math.max(2, 4 - Math.floor(nextLevel / 3)), // shrinks with level
        answerTimer:   ANSWER_TIMEOUT,
        startTime:     null,
      }
    }

    case 'RESTART':
      return {
        ...initialState,
        highScore:  state.highScore,
        bestStreak: state.bestStreak,
        phase:      PHASE.IDLE,
        heatmap:    {},
      }

    case 'SET_PHASE':
      return { ...state, phase: action.payload }

    default:
      return state
  }
}

/* ─── Context ─────────────────────────────────────────────── */
const GameContext = createContext(null)

export function GameProvider({ children }) {
  const [state, dispatch] = useReducer(gameReducer, initialState)

  /* Persist high score & best streak */
  useEffect(() => {
    saveToStorage('mm_highScore',  state.highScore)
    saveToStorage('mm_bestStreak', state.bestStreak)
  }, [state.highScore, state.bestStreak])

  /* ── Memorize countdown ──────────────────────────────────── */
  useEffect(() => {
    if (state.phase !== PHASE.MEMORIZE) return
    const id = setTimeout(() => dispatch({ type: 'TICK_MEMORIZE' }), 1000)
    return () => clearTimeout(id)
  }, [state.phase, state.memorizeTimer])

  /* ── Answer countdown ────────────────────────────────────── */
  useEffect(() => {
    if (state.phase !== PHASE.RECALL || ANSWER_TIMEOUT === 0) return
    const id = setTimeout(() => dispatch({ type: 'TICK_ANSWER' }), 1000)
    return () => clearTimeout(id)
  }, [state.phase, state.answerTimer])

  /* ── Auto-advance after validation flash (1s) ────────────── */
  useEffect(() => {
    if (state.phase !== PHASE.VALIDATING) return
    const id = setTimeout(() => dispatch({ type: 'SET_PHASE', payload: PHASE.LEVEL_UP }), 800)
    return () => clearTimeout(id)
  }, [state.phase])

  /* ── Level-up transition (1s) ─────────────────────────────── */
  useEffect(() => {
    if (state.phase !== PHASE.LEVEL_UP) return
    const id = setTimeout(() => dispatch({ type: 'NEXT_LEVEL' }), 900)
    return () => clearTimeout(id)
  }, [state.phase])

  const selectCell  = useCallback((idx) => dispatch({ type: 'SELECT_CELL', payload: idx }), [])
  const startGame   = useCallback(()      => dispatch({ type: 'START_GAME' }), [])
  const restartGame = useCallback(()      => dispatch({ type: 'RESTART' }), [])

  return (
    <GameContext.Provider value={{ state, selectCell, startGame, restartGame }}>
      {children}
    </GameContext.Provider>
  )
}

export function useGame() {
  const ctx = useContext(GameContext)
  if (!ctx) throw new Error('useGame must be used within GameProvider')
  return ctx
}
