/**
 * context/ThemeContext.jsx
 * ─────────────────────────────────────────────
 * Manages dark / light mode with localStorage persistence.
 */
import React, { createContext, useContext, useEffect, useState } from 'react'
import { loadFromStorage, saveToStorage } from '../utils/gameUtils'

const ThemeContext = createContext(null)

export function ThemeProvider({ children }) {
  const [isDark, setIsDark] = useState(() => loadFromStorage('mm_theme', true))

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark)
    saveToStorage('mm_theme', isDark)
  }, [isDark])

  const toggleTheme = () => setIsDark((v) => !v)

  return (
    <ThemeContext.Provider value={{ isDark, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const ctx = useContext(ThemeContext)
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider')
  return ctx
}
