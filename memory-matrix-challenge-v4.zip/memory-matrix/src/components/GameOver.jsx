/**
 * components/GameOver.jsx
 */
import React from 'react'
import { motion } from 'framer-motion'
import { useGame } from '../context/GameContext'
import Heatmap from './Heatmap'
import { levelLabel } from '../utils/gameUtils'

export default function GameOver() {
  const { state, restartGame, startGame } = useGame()

  const score      = state?.score      ?? 0
  const maxStreak  = state?.maxStreak  ?? 0
  const highScore  = state?.highScore  ?? 0
  const bestStreak = state?.bestStreak ?? 0
  const level      = state?.level      ?? 1
  const history    = Array.isArray(state?.history) ? state.history : []

  const isNewHigh   = score > 0 && score >= highScore
  const isNewStreak = maxStreak > 0 && maxStreak >= bestStreak
  const avgPoints   = history.length
    ? Math.round(history.reduce((a, r) => a + (r?.points ?? 0), 0) / history.length)
    : 0

  const emoji = score === 0 ? '💀' : score > 500 ? '🏆' : '🎯'

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-40 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(8px)' }}
    >
      <motion.div
        initial={{ scale: 0.8, y: 40 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.8, y: 40 }}
        transition={{ type: 'spring', stiffness: 280, damping: 24 }}
        className="glass rounded-2xl p-6 md:p-8 w-full max-w-lg border border-[var(--border-color)]"
        style={{ maxHeight: '90vh', overflowY: 'auto' }}
      >
        {/* Header */}
        <div className="text-center mb-6">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 300 }}
            className="text-5xl mb-3"
          >
            {emoji}
          </motion.div>
          <h2
            className="font-display text-2xl md:text-3xl font-bold mb-1"
            style={{ color: 'var(--neon-red)' }}
          >
            GAME OVER
          </h2>
          <p className="font-body text-sm" style={{ color: 'var(--text-secondary)' }}>
            You reached Level {level} &middot; {levelLabel(level)}
          </p>
        </div>

        {/* Score cards */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <ScoreCard
            label="FINAL SCORE"
            value={score.toLocaleString()}
            highlight={isNewHigh}
            badge={isNewHigh ? 'New Best!' : null}
            color="var(--neon-cyan)"
          />
          <ScoreCard
            label="BEST STREAK"
            value={'x' + maxStreak}
            highlight={isNewStreak}
            badge={isNewStreak ? 'New Best!' : null}
            color="var(--neon-green)"
          />
          <ScoreCard
            label="HIGH SCORE"
            value={highScore.toLocaleString()}
            color="var(--neon-purple)"
          />
          <ScoreCard
            label="AVG PTS/LVL"
            value={avgPoints.toLocaleString()}
            color="var(--neon-yellow)"
          />
        </div>

        {/* Heatmap */}
        <div
          className="mb-6 p-4 rounded-xl"
          style={{ background: 'rgba(0,0,0,0.3)', border: '1px solid var(--border-color)' }}
        >
          <Heatmap />
        </div>

        {/* Buttons */}
        <div className="flex gap-3">
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={startGame}
            className="flex-1 py-3 rounded-xl font-display text-sm tracking-widest font-bold"
            style={{
              background: 'linear-gradient(135deg, var(--neon-cyan), var(--neon-purple))',
              color: '#000',
              boxShadow: '0 0 20px rgba(0,245,255,0.3)',
            }}
          >
            PLAY AGAIN
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={restartGame}
            className="px-4 py-3 rounded-xl font-display text-sm tracking-widest glass border border-[var(--border-color)]"
            style={{ color: 'var(--text-secondary)' }}
          >
            MENU
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  )
}

function ScoreCard({ label, value, color, highlight, badge }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-xl p-3 text-center relative overflow-hidden"
      style={{
        background: highlight ? 'rgba(0,245,255,0.08)' : 'rgba(0,0,0,0.2)',
        border: '1px solid ' + (highlight ? color : 'var(--border-color)'),
        boxShadow: highlight ? '0 0 16px rgba(0,245,255,0.15)' : 'none',
      }}
    >
      {badge && (
        <span
          className="absolute top-1 right-1 text-[9px] font-bold"
          style={{ color }}
        >
          {badge}
        </span>
      )}
      <div className="font-display text-xl font-bold" style={{ color }}>
        {value}
      </div>
      <div
        className="font-mono text-[10px] tracking-widest mt-0.5"
        style={{ color: 'var(--text-secondary)' }}
      >
        {label}
      </div>
    </motion.div>
  )
}
