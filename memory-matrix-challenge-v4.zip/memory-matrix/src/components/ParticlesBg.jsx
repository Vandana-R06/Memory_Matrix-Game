/**
 * components/ParticlesBg.jsx
 * ─────────────────────────────────────────────
 * Lightweight CSS-only floating particle background.
 * Uses pure div elements animated via keyframes
 * so it doesn't conflict with Framer Motion.
 */
import React, { useMemo } from 'react'

const PARTICLE_COUNT = 22

export default function ParticlesBg() {
  const particles = useMemo(() => {
    return Array.from({ length: PARTICLE_COUNT }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: 1 + Math.random() * 3,
      duration: 8 + Math.random() * 16,
      delay: Math.random() * 10,
      color: i % 3 === 0
        ? 'var(--neon-cyan)'
        : i % 3 === 1
          ? 'var(--neon-purple)'
          : 'var(--neon-green)',
      opacity: 0.15 + Math.random() * 0.3,
    }))
  }, [])

  return (
    <div
      className="fixed inset-0 pointer-events-none overflow-hidden"
      style={{ zIndex: 0 }}
      aria-hidden="true"
    >
      <style>{`
        @keyframes floatUp {
          0%   { transform: translateY(0) translateX(0) scale(1); opacity: var(--op); }
          33%  { transform: translateY(-30px) translateX(12px) scale(1.2); }
          66%  { transform: translateY(-15px) translateX(-8px) scale(0.8); }
          100% { transform: translateY(-60px) translateX(5px) scale(1); opacity: 0; }
        }
      `}</style>
      {particles.map((p) => (
        <div
          key={p.id}
          style={{
            position: 'absolute',
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            borderRadius: '50%',
            background: p.color,
            '--op': p.opacity,
            opacity: p.opacity,
            animation: `floatUp ${p.duration}s ${p.delay}s ease-in-out infinite`,
            boxShadow: `0 0 ${p.size * 3}px ${p.color}`,
          }}
        />
      ))}
    </div>
  )
}
