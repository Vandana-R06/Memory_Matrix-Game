/**
 * components/Navbar.jsx
 * ─────────────────────────────────────────────
 * Top navigation bar with logo, score display
 * and dark/light mode toggle.
 */
import React from 'react'
import { motion } from 'framer-motion'
import { useTheme } from '../context/ThemeContext'
import { useGame, PHASE } from '../context/GameContext'

/* ─── Icons ──────────────────────────────────────────────── */
function SunIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}
      strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
      <circle cx="12" cy="12" r="5" />
      <line x1="12" y1="1"  x2="12" y2="3"  />
      <line x1="12" y1="21" x2="12" y2="23" />
      <line x1="4.22" y1="4.22"   x2="5.64" y2="5.64"   />
      <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
      <line x1="1"  y1="12" x2="3"  y2="12" />
      <line x1="21" y1="12" x2="23" y2="12" />
      <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"   />
      <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"   />
    </svg>
  )
}
function MoonIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}
      strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
      <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
    </svg>
  )
}
function MatrixIcon() {
  return (
    <svg viewBox="0 0 28 28" fill="none" className="w-7 h-7">
      {/* 3×3 grid preview */}
      {[0,1,2].map(row =>
        [0,1,2].map(col => (
          <rect
            key={`${row}-${col}`}
            x={col * 9 + 1} y={row * 9 + 1}
            width={7} height={7} rx={1.5}
            fill={((row + col) % 2 === 0) ? 'var(--neon-cyan)' : 'rgba(0,245,255,0.25)'}
          />
        ))
      )}
    </svg>
  )
}

export default function Navbar() {
  const { isDark, toggleTheme } = useTheme()
  const { state } = useGame()
  const inGame = state.phase !== PHASE.IDLE && state.phase !== PHASE.GAME_OVER

  return (
    <motion.nav
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="fixed top-0 inset-x-0 z-50 h-14"
    >
      {/* Glassmorphism bar */}
      <div className="glass h-full flex items-center justify-between px-4 md:px-8
                      border-b border-[var(--border-color)]">

        {/* Logo */}
        <div className="flex items-center gap-2">
          <MatrixIcon />
          <span className="font-display text-sm md:text-base font-bold tracking-widest
                           text-glow-cyan hidden sm:block"
            style={{ color: 'var(--neon-cyan)' }}>
            MEMORY MATRIX
          </span>
          <span className="font-display text-sm font-bold tracking-widest
                           text-glow-cyan sm:hidden"
            style={{ color: 'var(--neon-cyan)' }}>
            MM
          </span>
        </div>

        {/* Centre stats (only during game) */}
        {inGame && (
          <div className="flex items-center gap-4 md:gap-8 text-center">
            <Stat label="LVL" value={state.level} color="var(--neon-cyan)" />
            <Stat label="SCORE" value={state.score.toLocaleString()} color="var(--neon-purple)" />
            <Stat label="STREAK" value={`×${state.streak}`} color="var(--neon-green)" />
          </div>
        )}

        {/* Theme toggle */}
        <motion.button
          whileTap={{ scale: 0.85 }}
          whileHover={{ scale: 1.1 }}
          onClick={toggleTheme}
          className="p-2 rounded-lg glass border border-[var(--border-color)]
                     text-[var(--text-secondary)] hover:text-[var(--neon-cyan)]
                     transition-colors"
          aria-label="Toggle dark mode"
        >
          {isDark ? <SunIcon /> : <MoonIcon />}
        </motion.button>
      </div>
    </motion.nav>
  )
}

function Stat({ label, value, color }) {
  return (
    <div className="flex flex-col items-center leading-none">
      <span className="font-mono text-[10px] tracking-widest"
        style={{ color: 'var(--text-secondary)' }}>
        {label}
      </span>
      <motion.span
        key={value}
        initial={{ scale: 1.3, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="font-display text-sm md:text-base font-bold"
        style={{ color }}
      >
        {value}
      </motion.span>
    </div>
  )
}
