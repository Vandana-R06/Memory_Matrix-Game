/**
 * components/Grid.jsx
 * ─────────────────────────────────────────────
 * Renders the N×N game grid.
 * Cell size is clamped so it fits any viewport.
 * Animates in/out on level transitions.
 */
import React, { useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Cell from './Cell'
import { useGame, PHASE } from '../context/GameContext'

/* Max grid container size in px (responsive) */
const MAX_GRID_PX = 480

export default function Grid() {
  const { state } = useGame()
  const { gridSize, level, phase } = state

  /* Gap between cells (px) */
  const gap = useMemo(() => {
    if (gridSize <= 3) return 12
    if (gridSize <= 4) return 10
    if (gridSize <= 5) return 8
    return 6
  }, [gridSize])

  /* Cell size: fill container minus gaps */
  const cellSize = useMemo(() => {
    const totalGap = gap * (gridSize - 1)
    return Math.floor((MAX_GRID_PX - totalGap) / gridSize)
  }, [gridSize, gap])

  const cellCount = gridSize * gridSize

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={`grid-${level}`}
        initial={{ opacity: 0, scale: 0.85, rotateX: 15 }}
        animate={{ opacity: 1, scale: 1, rotateX: 0 }}
        exit={{ opacity: 0, scale: 0.85, rotateX: -15 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        style={{
          display: 'grid',
          gridTemplateColumns: `repeat(${gridSize}, ${cellSize}px)`,
          gap: `${gap}px`,
          width: 'fit-content',
          margin: '0 auto',
        }}
        className="select-none"
        aria-label={`Memory grid ${gridSize}×${gridSize}`}
      >
        {Array.from({ length: cellCount }, (_, i) => (
          <div key={i} style={{ width: cellSize, height: cellSize, position: 'relative' }}>
            <Cell index={i} />
          </div>
        ))}

        {/* Scanning line overlay during memorize */}
        {phase === PHASE.MEMORIZE && (
          <motion.div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: 'linear-gradient(transparent 40%, rgba(0,245,255,0.08) 50%, transparent 60%)',
            }}
            animate={{ y: ['0%', '100%'] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
          />
        )}
      </motion.div>
    </AnimatePresence>
  )
}
