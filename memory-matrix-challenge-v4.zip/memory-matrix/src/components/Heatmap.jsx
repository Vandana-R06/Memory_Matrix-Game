/**
 * components/Heatmap.jsx
 * ─────────────────────────────────────────────
 * Visual heatmap of cells where the user made
 * incorrect clicks. Darker / more saturated =
 * more mistakes on that cell.
 * Displayed on the Game Over / Result screen.
 */
import React, { useMemo } from 'react'
import { motion } from 'framer-motion'
import { useGame } from '../context/GameContext'
import { useTheme } from '../context/ThemeContext'
import { heatmapColor } from '../utils/gameUtils'

const DISPLAY_SIZE = 6   // always show a 6×6 representation

export default function Heatmap() {
  const { state }     = useGame()
  const { isDark }    = useTheme()
  const { heatmap, gridSize } = state

  /* Normalise mistake counts */
  const counts  = Object.values(heatmap)
  const maxCount = counts.length > 0 ? Math.max(...counts) : 1

  /* Build 6×6 display grid (pad smaller grids) */
  const cells = useMemo(() => {
    const total = DISPLAY_SIZE * DISPLAY_SIZE
    return Array.from({ length: total }, (_, i) => ({
      index:  i,
      count:  heatmap[i] || 0,
    }))
  }, [heatmap])

  const hasData = counts.length > 0

  return (
    <div className="flex flex-col items-center gap-3">
      <h3 className="font-display text-xs tracking-widest"
        style={{ color: 'var(--text-secondary)' }}>
        MISTAKE HEATMAP
      </h3>

      {!hasData ? (
        <p className="font-body text-sm" style={{ color: 'var(--text-secondary)' }}>
          No mistakes recorded — impressive!
        </p>
      ) : (
        <>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: `repeat(${DISPLAY_SIZE}, 28px)`,
              gap: '4px',
            }}
          >
            {cells.map(({ index, count }) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.008, type: 'spring', stiffness: 300, damping: 20 }}
                style={{
                  width:  28,
                  height: 28,
                  borderRadius: 4,
                  background: heatmapColor(count, maxCount, isDark),
                  boxShadow: count > 0
                    ? `0 0 ${4 + count * 3}px rgba(255,${Math.round(255*(1 - count/maxCount))},0,0.5)`
                    : 'none',
                }}
                title={count > 0 ? `${count} mistake${count > 1 ? 's' : ''}` : ''}
              />
            ))}
          </div>

          {/* Legend */}
          <div className="flex items-center gap-2 mt-1">
            <div className="flex gap-1">
              {[0.1, 0.3, 0.5, 0.7, 1.0].map((t, i) => (
                <div key={i} style={{
                  width: 14, height: 14, borderRadius: 3,
                  background: `rgba(255,${Math.round(255*(1-t))},0,${0.3 + t*0.7})`,
                }} />
              ))}
            </div>
            <span className="font-mono text-[10px]" style={{ color: 'var(--text-secondary)' }}>
              Few → Many
            </span>
          </div>
        </>
      )}
    </div>
  )
}
