/**
 * components/Timer.jsx
 * Fixed: all hooks must run unconditionally before any return.
 */
import React, { useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useGame, PHASE } from '../context/GameContext'
import { useSound } from '../hooks/useSound'

const RADIUS = 28
const CIRC   = 2 * Math.PI * RADIUS
const ANSWER_TIMEOUT = 15

export default function Timer() {
  const { state }    = useGame()
  const { playTick } = useSound()
  const prevTick     = useRef(null)

  const { phase, memorizeTimer, answerTimer } = state

  const isMemorize = phase === PHASE.MEMORIZE
  const isRecall   = phase === PHASE.RECALL
  const isVisible  = isMemorize || isRecall

  const current = isMemorize ? memorizeTimer : answerTimer
  const max     = isMemorize ? 3 : ANSWER_TIMEOUT

  // ALL hooks must be called before any conditional return
  useEffect(() => {
    if (!isVisible) return
    if (current !== prevTick.current) {
      prevTick.current = current
      if (isRecall && current <= 5 && current > 0) playTick()
    }
  }, [current, isRecall, isVisible, playTick])

  // Conditional return AFTER all hooks
  if (!isVisible) return null

  const fraction   = max > 0 ? current / max : 0
  const strokeDash = fraction * CIRC
  const color = isMemorize
    ? 'var(--neon-cyan)'
    : current <= 5 ? 'var(--neon-red)' : 'var(--neon-yellow)'

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.7 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.7 }}
        className="flex flex-col items-center gap-1"
      >
        <div className="relative flex items-center justify-center">
          <svg width={70} height={70} style={{ transform: 'rotate(-90deg)' }}>
            <circle
              cx={35} cy={35} r={RADIUS}
              fill="none"
              stroke="rgba(255,255,255,0.08)"
              strokeWidth={4}
            />
            <motion.circle
              cx={35} cy={35} r={RADIUS}
              fill="none"
              stroke={color}
              strokeWidth={4}
              strokeLinecap="round"
              strokeDasharray={CIRC}
              animate={{ strokeDashoffset: CIRC - strokeDash }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
              style={{ filter: `drop-shadow(0 0 6px ${color})` }}
            />
          </svg>
          <motion.span
            key={current}
            initial={{ scale: 1.4, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.2 }}
            className="absolute font-display text-xl font-bold"
            style={{ color }}
          >
            {current}
          </motion.span>
        </div>
        <span
          className="font-mono text-[10px] tracking-widest"
          style={{ color: 'var(--text-secondary)' }}
        >
          {isMemorize ? 'MEMORIZE' : 'ANSWER'}
        </span>
      </motion.div>
    </AnimatePresence>
  )
}
