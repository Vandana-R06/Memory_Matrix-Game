/**
 * components/ProgressBar.jsx
 * ─────────────────────────────────────────────
 * Horizontal level progress bar.
 * Fills from 0→100% as the player advances through
 * the current difficulty tier (3 levels per tier).
 */
import React from 'react'
import { motion } from 'framer-motion'
import { useGame } from '../context/GameContext'
import { levelLabel, getGridSize } from '../utils/gameUtils'

export default function ProgressBar() {
  const { state } = useGame()
  const { level, score, streak } = state

  /* Each tier is 3 levels; compute progress within tier */
  const tierSize   = 3
  const tierStart  = Math.floor((level - 1) / tierSize) * tierSize + 1
  const tierEnd    = tierStart + tierSize - 1
  const progress   = ((level - tierStart) / tierSize) * 100
  const gridSize   = getGridSize(level)

  return (
    <div className="w-full max-w-md mx-auto flex flex-col gap-1.5">

      {/* Labels */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="font-display text-xs tracking-widest"
            style={{ color: 'var(--neon-cyan)' }}>
            LVL {level}
          </span>
          <span className="font-mono text-[10px] px-2 py-0.5 rounded-full"
            style={{ background: 'rgba(191,0,255,0.15)', color: 'var(--neon-purple)' }}>
            {levelLabel(level)}
          </span>
          <span className="font-mono text-[10px]"
            style={{ color: 'var(--text-secondary)' }}>
            {gridSize}×{gridSize}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {streak > 0 && (
            <motion.span
              key={streak}
              initial={{ scale: 1.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="font-display text-xs"
              style={{ color: 'var(--neon-green)' }}
            >
              🔥 ×{streak}
            </motion.span>
          )}
          <span className="font-mono text-xs"
            style={{ color: 'var(--text-secondary)' }}>
            {score.toLocaleString()} pts
          </span>
        </div>
      </div>

      {/* Bar */}
      <div className="progress-bar w-full">
        <motion.div
          className="progress-fill"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        />
      </div>

      {/* Tier ticks */}
      <div className="flex justify-between">
        {Array.from({ length: tierSize }, (_, i) => (
          <span key={i}
            className="font-mono text-[9px]"
            style={{ color: level - tierStart > i ? 'var(--neon-cyan)' : 'var(--text-secondary)' }}>
            {tierStart + i}
          </span>
        ))}
      </div>
    </div>
  )
}
