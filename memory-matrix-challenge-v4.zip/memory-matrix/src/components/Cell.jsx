/**
 * components/Cell.jsx
 * ─────────────────────────────────────────────
 * Individual grid cell with animated states:
 *  revealed  → cyan glow (memorize phase)
 *  selected  → subtle highlight (user has clicked)
 *  correct   → green glow (pattern confirmed)
 *  wrong     → red shake (wrong pick → game over)
 */
import React, { useCallback, useRef } from 'react'
import { motion } from 'framer-motion'
import { useGame, PHASE } from '../context/GameContext'
import { useSound } from '../hooks/useSound'

export default function Cell({ index }) {
  const { state, selectCell } = useGame()
  const { playClick, playWrong } = useSound()
  const rippleRef = useRef(null)

  const { phase, pattern, userSelection } = state

  /* ── Derive visual state ─────────────────────────────────── */
  const isRevealed  = phase === PHASE.MEMORIZE && pattern.includes(index)
  const isSelected  = userSelection.includes(index)
  const isInPattern = pattern.includes(index)

  // After validation flash: show all correct / wrong
  const showResult  = phase === PHASE.VALIDATING || phase === PHASE.LEVEL_UP || phase === PHASE.GAME_OVER
  const isCorrect   = showResult && isSelected && isInPattern
  const isWrong     = showResult && isSelected && !isInPattern
  const isMissed    = showResult && !isSelected && isInPattern  // pattern cell not clicked

  const isDisabled  = phase !== PHASE.RECALL || isSelected

  /* ── Class composition ───────────────────────────────────── */
  let cellClass = 'cell'
  if (isRevealed) cellClass += ' cell--revealed'
  else if (isCorrect || (phase === PHASE.VALIDATING && isInPattern)) cellClass += ' cell--correct'
  else if (isWrong)    cellClass += ' cell--wrong'
  else if (isMissed)   cellClass += ' cell--revealed'   // show where they should have clicked
  else if (isSelected) cellClass += ' cell--selected'
  if (isDisabled)      cellClass += ' cell--disabled'

  /* ── Click handler with ripple ───────────────────────────── */
  const handleClick = useCallback((e) => {
    if (isDisabled) return
    // Ripple effect
    const rect   = e.currentTarget.getBoundingClientRect()
    const x      = e.clientX - rect.left
    const y      = e.clientY - rect.top
    const ripple = document.createElement('span')
    ripple.style.cssText = `
      position:absolute; border-radius:50%; pointer-events:none;
      width:${rect.width * 2}px; height:${rect.width * 2}px;
      left:${x - rect.width}px; top:${y - rect.width}px;
      background:rgba(0,245,255,0.35);
      animation:ripple 0.6s ease-out forwards;
    `
    e.currentTarget.appendChild(ripple)
    setTimeout(() => ripple.remove(), 600)

    // Sound
    if (pattern.includes(index)) playClick()
    else playWrong()

    selectCell(index)
  }, [isDisabled, index, pattern, playClick, playWrong, selectCell])

  return (
    <motion.div
      role="button"
      tabIndex={isDisabled ? -1 : 0}
      aria-label={`Cell ${index}`}
      aria-pressed={isSelected}
      className={cellClass}
      onClick={handleClick}
      onKeyDown={(e) => e.key === 'Enter' && handleClick(e)}
      initial={{ opacity: 0, scale: 0.7 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.7 }}
      transition={{
        type: 'spring',
        stiffness: 300,
        damping: 20,
        delay: index * 0.015,
      }}
      whileHover={!isDisabled ? { scale: 1.06, zIndex: 2 } : {}}
      whileTap={!isDisabled ? { scale: 0.94 } : {}}
      style={{ position: 'absolute', inset: 0 }}
    >
      {/* Inner shimmer on revealed */}
      {isRevealed && (
        <motion.div
          className="absolute inset-0 rounded-lg"
          style={{ background: 'rgba(255,255,255,0.15)' }}
          animate={{ opacity: [0.2, 0.5, 0.2] }}
          transition={{ duration: 1.2, repeat: Infinity }}
        />
      )}
    </motion.div>
  )
}
