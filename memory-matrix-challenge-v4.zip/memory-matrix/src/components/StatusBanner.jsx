/**
 * components/StatusBanner.jsx
 * ─────────────────────────────────────────────
 * Animated banner shown between phases:
 *  MEMORIZE   → "Study the pattern"
 *  RECALL     → "Now reproduce it"
 *  VALIDATING → "Correct! 🎉"
 *  LEVEL_UP   → "Level X!"
 */
import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useGame, PHASE } from '../context/GameContext'

const MESSAGES = {
  [PHASE.MEMORIZE]:   { text: 'Study the pattern…', color: 'var(--neon-cyan)',   icon: '👁️' },
  [PHASE.RECALL]:     { text: 'Reproduce it!',       color: 'var(--neon-yellow)', icon: '🧠' },
  [PHASE.VALIDATING]: { text: 'Correct!',            color: 'var(--neon-green)',  icon: '✅' },
  [PHASE.LEVEL_UP]:   { text: 'Level Up!',           color: 'var(--neon-purple)', icon: '🚀' },
}

export default function StatusBanner() {
  const { state } = useGame()
  const msg = MESSAGES[state.phase]

  return (
    <AnimatePresence mode="wait">
      {msg && (
        <motion.div
          key={state.phase}
          initial={{ opacity: 0, y: -16, scale: 0.92 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 16, scale: 0.92 }}
          transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className="flex items-center gap-2 px-5 py-2 rounded-full glass
                     border border-[var(--border-color)]"
        >
          <span className="text-lg">{msg.icon}</span>
          <span
            className="font-display text-sm tracking-widest font-bold"
            style={{ color: msg.color }}
          >
            {msg.text}
          </span>
          {state.phase === PHASE.LEVEL_UP && (
            <span className="font-display text-sm font-bold"
              style={{ color: 'var(--neon-cyan)' }}>
              {state.level}
            </span>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  )
}
