/**
 * hooks/useSound.js
 * ─────────────────────────────────────────────
 * Web Audio API sound effects hook.
 * Generates tones procedurally — no audio files required.
 * Returns play functions that are safe to call even if
 * the AudioContext hasn't been unlocked yet (auto-resumes).
 */
import { useRef, useCallback } from 'react'

function createCtx() {
  try {
    return new (window.AudioContext || window.webkitAudioContext)()
  } catch (_) {
    return null
  }
}

/**
 * Plays a simple beep.
 * @param {AudioContext} ctx
 * @param {number} freq     - frequency in Hz
 * @param {number} duration - seconds
 * @param {string} type     - OscillatorType (sine|square|sawtooth|triangle)
 * @param {number} gain     - volume 0–1
 */
function beep(ctx, freq, duration, type = 'sine', gain = 0.18) {
  if (!ctx) return
  try {
    const osc = ctx.createOscillator()
    const vol = ctx.createGain()
    osc.connect(vol)
    vol.connect(ctx.destination)
    osc.type      = type
    osc.frequency.setValueAtTime(freq, ctx.currentTime)
    vol.gain.setValueAtTime(gain, ctx.currentTime)
    vol.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration)
    osc.start(ctx.currentTime)
    osc.stop(ctx.currentTime + duration)
  } catch (_) { /* Ignore if context suspended */ }
}

export function useSound() {
  const ctxRef = useRef(null)

  /** Lazily create / resume AudioContext on first user gesture */
  const getCtx = useCallback(() => {
    if (!ctxRef.current) ctxRef.current = createCtx()
    if (ctxRef.current?.state === 'suspended') {
      ctxRef.current.resume().catch(() => {})
    }
    return ctxRef.current
  }, [])

  /** Cell click – soft tick */
  const playClick = useCallback(() => {
    beep(getCtx(), 880, 0.1, 'sine', 0.12)
  }, [getCtx])

  /** Pattern reveal – ascending arpeggio */
  const playReveal = useCallback(() => {
    const ctx = getCtx()
    if (!ctx) return
    const notes = [523, 659, 784, 1047]
    notes.forEach((f, i) => {
      setTimeout(() => beep(ctx, f, 0.15, 'sine', 0.15), i * 80)
    })
  }, [getCtx])

  /** Correct answer – triumphant chord */
  const playCorrect = useCallback(() => {
    const ctx = getCtx()
    if (!ctx) return
    beep(ctx, 523, 0.2, 'sine', 0.15)
    setTimeout(() => beep(ctx, 659, 0.2, 'sine', 0.15), 100)
    setTimeout(() => beep(ctx, 784, 0.3, 'sine', 0.18), 200)
  }, [getCtx])

  /** Wrong answer – low buzzer */
  const playWrong = useCallback(() => {
    const ctx = getCtx()
    if (!ctx) return
    beep(ctx, 180, 0.4, 'sawtooth', 0.15)
    setTimeout(() => beep(ctx, 120, 0.5, 'sawtooth', 0.18), 150)
  }, [getCtx])

  /** Level up – fanfare */
  const playLevelUp = useCallback(() => {
    const ctx = getCtx()
    if (!ctx) return
    const fanfare = [523, 659, 784, 1047, 1319]
    fanfare.forEach((f, i) => {
      setTimeout(() => beep(ctx, f, 0.18, 'sine', 0.18), i * 90)
    })
  }, [getCtx])

  /** Countdown tick – high click */
  const playTick = useCallback(() => {
    beep(getCtx(), 1200, 0.06, 'square', 0.08)
  }, [getCtx])

  return { playClick, playReveal, playCorrect, playWrong, playLevelUp, playTick }
}
