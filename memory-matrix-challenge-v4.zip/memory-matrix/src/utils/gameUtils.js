/**
 * utils/gameUtils.js
 * ─────────────────────────────────────────────
 * Pure helper functions for game logic.
 * No side effects — safe to test independently.
 */

/* ─── Grid / Pattern Helpers ─────────────────────────────── */

/**
 * Returns the grid dimension (N×N) for a given level.
 * Level  1–3  → 3×3
 * Level  4–6  → 4×4
 * Level  7–9  → 5×5
 * Level 10+   → 6×6
 */
export function getGridSize(level) {
  if (level <= 3)  return 3
  if (level <= 6)  return 4
  if (level <= 9)  return 5
  return 6
}

/**
 * Returns how many cells should be highlighted for a given level.
 * Scales from 3 up to ~60% of the grid.
 */
export function getPatternLength(level) {
  const gridSize    = getGridSize(level)
  const totalCells  = gridSize * gridSize
  const base        = 3
  const extra       = level - 1               // +1 cell per level
  const max         = Math.floor(totalCells * 0.65)
  return Math.min(base + extra, max)
}

/**
 * Returns a random array of unique cell indices for the pattern.
 * @param {number} gridSize  - N (grid is N×N)
 * @param {number} count     - how many cells to highlight
 */
export function generatePattern(gridSize, count) {
  const total   = gridSize * gridSize
  const indices = Array.from({ length: total }, (_, i) => i)
  // Fisher-Yates shuffle, then take first `count`
  for (let i = indices.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[indices[i], indices[j]] = [indices[j], indices[i]]
  }
  return indices.slice(0, count)
}

/* ─── Score Calculation ──────────────────────────────────── */

/**
 * Score = base × level + time bonus.
 * Faster answers earn more points.
 * @param {number} level    - current level
 * @param {number} elapsed  - seconds taken to answer
 */
export function calculateScore(level, elapsed) {
  const base      = 100 * level
  const timeBonus = Math.max(0, Math.floor((15 - elapsed) * 10))
  return base + timeBonus
}

/* ─── LocalStorage Helpers ───────────────────────────────── */

export function saveToStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch (_) {
    // Silently fail in private browsing / storage-full scenarios
  }
}

export function loadFromStorage(key, fallback) {
  try {
    const raw = localStorage.getItem(key)
    return raw !== null ? JSON.parse(raw) : fallback
  } catch (_) {
    return fallback
  }
}

/* ─── Heatmap Helpers ─────────────────────────────────────── */

/**
 * Returns an RGBA string for heatmap cell based on mistake count.
 * More mistakes → deeper red.
 * @param {number} count  - number of incorrect clicks on this cell
 * @param {number} maxCount - maximum across all cells (for normalization)
 * @param {boolean} isDark
 */
export function heatmapColor(count, maxCount, isDark) {
  if (!count) {
    return isDark ? 'rgba(30,30,60,0.9)' : 'rgba(226,232,248,0.9)'
  }
  const t = maxCount > 0 ? count / maxCount : 0
  // Interpolate from yellow (low) → red (high)
  const r = Math.round(255)
  const g = Math.round(255 * (1 - t))
  const a = 0.3 + t * 0.7
  return `rgba(${r},${g},0,${a})`
}

/* ─── Formatting Helpers ─────────────────────────────────── */

/** Pad number to 2 digits: 5 → "05" */
export function pad2(n) {
  return String(n).padStart(2, '0')
}

/** Format seconds as MM:SS */
export function formatTime(seconds) {
  return `${pad2(Math.floor(seconds / 60))}:${pad2(seconds % 60)}`
}

/** Human-readable level description */
export function levelLabel(level) {
  if (level <= 3)  return 'Novice'
  if (level <= 6)  return 'Apprentice'
  if (level <= 9)  return 'Adept'
  if (level <= 12) return 'Expert'
  return 'Master'
}
