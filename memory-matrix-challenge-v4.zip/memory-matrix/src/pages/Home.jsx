/**
 * pages/Home.jsx
 * ─────────────────────────────────────────────
 * Landing / title screen shown before game starts.
 * Features:
 *  - Animated logo grid preview
 *  - High score / best streak display
 *  - How to play rules
 *  - Start button
 */
import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useGame } from '../context/GameContext'

/* ── Animated mini-grid preview ─────────────────────────── */
function MiniGridPreview() {
  const SIZE  = 4
  const CELLS = SIZE * SIZE
  const [lit, setLit] = React.useState([1, 5, 9, 14, 3])

  React.useEffect(() => {
    const cycle = () => {
      const count  = 3 + Math.floor(Math.random() * 5)
      const all    = Array.from({ length: CELLS }, (_, i) => i)
      const picked = all.sort(() => Math.random() - 0.5).slice(0, count)
      setLit(picked)
    }
    cycle()
    const id = setInterval(cycle, 2000)
    return () => clearInterval(id)
  }, [])

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: `repeat(${SIZE}, 40px)`,
        gap: '6px',
      }}
    >
      {Array.from({ length: CELLS }, (_, i) => (
        <motion.div
          key={i}
          animate={{
            background: lit.includes(i) ? 'var(--neon-cyan)' : 'var(--cell-idle)',
            boxShadow: lit.includes(i)
              ? '0 0 12px var(--neon-cyan), 0 0 30px rgba(0,245,255,0.3)'
              : 'none',
          }}
          transition={{ duration: 0.4 }}
          style={{
            width: 40, height: 40,
            borderRadius: 6,
            border: '1px solid var(--border-color)',
          }}
        />
      ))}
    </div>
  )
}

/* ── Rule item ──────────────────────────────────────────── */
function Rule({ icon, text }) {
  return (
    <div className="flex items-start gap-3">
      <span className="text-xl">{icon}</span>
      <span className="font-body text-sm leading-relaxed"
        style={{ color: 'var(--text-secondary)' }}>
        {text}
      </span>
    </div>
  )
}

/* ── Main component ─────────────────────────────────────── */
export default function Home() {
  const { state, startGame } = useGame()
  const [showRules, setShowRules] = useState(false)

  const hasHighScore = state.highScore > 0

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen flex flex-col items-center justify-center px-4 pt-16 pb-8"
    >
      {/* Hero section */}
      <motion.div
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.1, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="text-center mb-8"
      >
        <h1 className="font-display text-4xl md:text-6xl font-black tracking-widest mb-2"
          style={{ color: 'var(--neon-cyan)' }}>
          MEMORY
        </h1>
        <h1 className="font-display text-4xl md:text-6xl font-black tracking-widest"
          style={{ color: 'var(--neon-purple)' }}>
          MATRIX
        </h1>
        <p className="font-body text-sm md:text-base mt-3"
          style={{ color: 'var(--text-secondary)' }}>
          Challenge your pattern recognition. How deep can you go?
        </p>
      </motion.div>

      {/* Grid preview */}
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="mb-8 p-6 rounded-2xl glass border border-[var(--border-color)]"
      >
        <MiniGridPreview />
      </motion.div>

      {/* High score badges */}
      {hasHighScore && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex gap-4 mb-6"
        >
          <Badge label="HIGH SCORE" value={state.highScore.toLocaleString()} color="var(--neon-cyan)" />
          <Badge label="BEST STREAK" value={`×${state.bestStreak}`} color="var(--neon-green)" />
        </motion.div>
      )}

      {/* Start button */}
      <motion.button
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.55 }}
        whileHover={{ scale: 1.06 }}
        whileTap={{ scale: 0.96 }}
        onClick={startGame}
        className="px-10 py-4 rounded-2xl font-display text-lg tracking-widest font-bold
                   mb-4 transition-all"
        style={{
          background: 'linear-gradient(135deg, var(--neon-cyan), var(--neon-purple))',
          color: '#000',
          boxShadow: '0 0 30px rgba(0,245,255,0.4), 0 0 60px rgba(191,0,255,0.2)',
        }}
      >
        {hasHighScore ? 'PLAY AGAIN' : 'START GAME'}
      </motion.button>

      {/* How to play toggle */}
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.65 }}
        onClick={() => setShowRules((v) => !v)}
        className="font-mono text-xs tracking-widest py-2 px-4 rounded-lg
                   glass border border-[var(--border-color)] transition-colors"
        style={{ color: 'var(--text-secondary)' }}
      >
        {showRules ? 'HIDE RULES ▲' : 'HOW TO PLAY ▼'}
      </motion.button>

      <AnimatePresence>
        {showRules && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.4 }}
            className="overflow-hidden w-full max-w-sm mt-4"
          >
            <div className="glass rounded-2xl p-5 border border-[var(--border-color)]
                            flex flex-col gap-3">
              <Rule icon="👁️" text="A pattern of cells will light up for 2–3 seconds." />
              <Rule icon="🧠" text="Memorize which cells were highlighted." />
              <Rule icon="🖱️" text="Click the same cells to reproduce the pattern." />
              <Rule icon="✅" text="Correct → next level with a larger grid and longer pattern." />
              <Rule icon="❌" text="One wrong click = Game Over. No second chances!" />
              <Rule icon="⚡" text="Answer faster to earn bonus points." />
              <Rule icon="🔥" text="Build streaks for multiplied glory." />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

function Badge({ label, value, color }) {
  return (
    <div className="flex flex-col items-center px-4 py-2 rounded-xl glass
                    border border-[var(--border-color)]">
      <span className="font-display text-lg font-bold" style={{ color }}>{value}</span>
      <span className="font-mono text-[10px] tracking-widest"
        style={{ color: 'var(--text-secondary)' }}>{label}</span>
    </div>
  )
}
