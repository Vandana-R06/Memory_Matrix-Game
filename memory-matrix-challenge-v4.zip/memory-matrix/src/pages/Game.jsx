/**
 * pages/Game.jsx
 * Fixed: hooks-before-return rule enforced in all sub-components.
 */
import React, { useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useGame, PHASE } from '../context/GameContext'
import { useSound } from '../hooks/useSound'
import Grid from '../components/Grid'
import Timer from '../components/Timer'
import ProgressBar from '../components/ProgressBar'
import StatusBanner from '../components/StatusBanner'

/* ── Pattern counter dots ───────────────────────────────── */
function PatternCounter() {
  const { state } = useGame()
  const { pattern, userSelection, phase } = state

  // Conditional render via variable — hooks always run
  const show = phase === PHASE.RECALL
  if (!show) return null

  const remaining = pattern.length - userSelection.length

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex items-center gap-2 flex-wrap justify-center"
    >
      {Array.from({ length: pattern.length }, (_, i) => (
        <motion.div
          key={i}
          animate={{
            background: i < userSelection.length
              ? 'var(--neon-green)'
              : 'rgba(255,255,255,0.2)',
            boxShadow: i < userSelection.length
              ? '0 0 8px var(--neon-green)'
              : 'none',
          }}
          style={{ width: 10, height: 10, borderRadius: '50%', flexShrink: 0 }}
        />
      ))}
      <span className="font-mono text-xs ml-1" style={{ color: 'var(--text-secondary)' }}>
        {remaining} left
      </span>
    </motion.div>
  )
}

/* ── Level-up burst ─────────────────────────────────────── */
function LevelUpBurst() {
  const { state } = useGame()
  // No hooks here — safe to return early based on prop/state
  if (state.phase !== PHASE.LEVEL_UP) return null

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: [0, 1, 0] }}
      transition={{ duration: 0.8 }}
      className="fixed inset-0 pointer-events-none z-30 flex items-center justify-center"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: [0, 2, 3] }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        style={{
          width: 200, height: 200,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(0,245,255,0.3) 0%, transparent 70%)',
        }}
      />
    </motion.div>
  )
}

/* ── Main Game page ─────────────────────────────────────── */
export default function Game() {
  const { state } = useGame()
  const { playReveal, playCorrect, playLevelUp } = useSound()

  // Hooks always run — no early return before this
  useEffect(() => {
    if (state.phase === PHASE.MEMORIZE)   playReveal()
    if (state.phase === PHASE.VALIDATING) playCorrect()
    if (state.phase === PHASE.LEVEL_UP)   playLevelUp()
  }, [state.phase]) // eslint-disable-line

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen flex flex-col items-center justify-center
                 pt-20 pb-8 px-4 gap-5"
    >
      <LevelUpBurst />

      <div className="w-full max-w-md">
        <ProgressBar />
      </div>

      <div className="flex items-center justify-between w-full max-w-md gap-4">
        <StatusBanner />
        <Timer />
      </div>

      <div className="flex items-center justify-center w-full">
        <Grid />
      </div>

      <PatternCounter />

      <AnimatePresence>
        {state.phase === PHASE.RECALL && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            exit={{ opacity: 0 }}
            className="font-mono text-xs text-center"
            style={{ color: 'var(--text-secondary)' }}
          >
            Click the highlighted cells in any order
          </motion.p>
        )}
      </AnimatePresence>
    </motion.div>
  )
}
